thisdict = { 
 "brand": "AUDI", 
 "model": "Q7", 
 "year": 2025
} 
thisdict["color"] = "BLACK"
print(thisdict)