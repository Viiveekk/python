a = 5
b = 10

print(f"Before swap: a = {a}, b = {b}")
a = a ^ b
b = a ^ b
a = a ^ b

print(f"After swap: a = {a}, b = {b}")