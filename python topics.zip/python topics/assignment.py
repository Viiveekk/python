cart = [
    {"item": "Apple", "price": 200},
    {"item": "Banana", "price": 2},
    {"item": "Bread", "price": 2},
    {"item": "Milk", "price": 1},
    {"item": "Eggs", "price": 1}
]

total_price = 0

for item in cart:
    total_price += item["price"]

print("Total_price:", total_price)
