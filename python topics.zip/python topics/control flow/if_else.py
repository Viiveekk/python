# num = int(input("enter the number:"))     
# if num%2 == 0:      
# #  print("The Given number is an even number")  




num = int(input("enter the number:"))           
if num%2 == 0:        
    print("The Given number is an even number")    
else:    
    print("The Given Number is an odd number")    
