num = int(input("Enter a number: "))

if num % 2 == 0 and num % 3 == 0:
    num = num ** 2  
    num += 5        
    print("Result:", num)
else:
    print("Not divisible by both 2 and 3.")