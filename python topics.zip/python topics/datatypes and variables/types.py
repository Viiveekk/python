# a = 22
# c = "vivek"
# print(a)
# print(c)


# x = 22
# y = "vivek"
# print(type(x)) 
# print(type(y))

# x, y, z = "hii", "hello", 'bye'
# print(x) 
# print(y) 
# print(z)




# x = y = z = "Tata, Goodbye" 
# print(x) 
# print(y) 
# print(z)



x = int(1) 
y = int(2.8) 
z = int("3") 
print(x) 
print(y) 
print(z)