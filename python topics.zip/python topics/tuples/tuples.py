thistuple = ("apple", "banana", "cherry") 
print(len(thistuple))