fruits = ["Apple", "Banana", "Cherry"]
for fruit in fruits:
    print(fruit)
