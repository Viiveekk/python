"""def area_of_rectangle(length,breadth):
    return length * breadth
length=2
breadth=5
area_of_rectangle = length * breadth

print("area_of_rectangle = "+str(area_of_rectangle))"""
 


import math
r=int(input("enter radius:"))
r=int(input("enter radius:"))
y= math.pi
x=y*(r**2)
print(x)