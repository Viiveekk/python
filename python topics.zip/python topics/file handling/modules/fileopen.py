f = open("demo.txt", "r") 
print(f.read())