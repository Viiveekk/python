
set1 = {"abc", 34, True, 40, "male"} 
myset = {"apple", "banana", "cherry"} 
print(type(myset))